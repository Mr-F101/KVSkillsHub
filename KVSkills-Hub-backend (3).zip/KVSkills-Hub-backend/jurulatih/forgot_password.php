<?php
declare(strict_types=1);
require_once dirname(__DIR__) . '/config/bootstrap.php';

if (Auth::check()) {
    $role = Auth::role();
    if ($role === 'coach') redirect('jurulatih/dashboard.php');
    if ($role === 'admin') redirect('admin/dashboard.php');
    redirect('pegawai_teknikal/dashboard.php');
}

if (is_post()) {
    Csrf::verify();
    $email       = mb_strtolower(trim((string)input('email')));
    $icInput     = trim((string)input('ic_number'));
    $newPass     = (string)input('new_password');
    $confirmPass = (string)input('confirm_password');
    $errors      = [];

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = 'Sila masukkan format e-mel yang sah.';
    }
    if ($icInput === '') {
        $errors[] = 'Sila masukkan No. Kad Pengenalan anda.';
    }
    if (strlen($newPass) < 8) {
        $errors[] = 'Kata laluan baharu mesti sekurang-kurangnya 8 aksara.';
    }
    if ($newPass !== $confirmPass) {
        $errors[] = 'Pengesahan kata laluan tidak sepadan.';
    }

    if (!$errors) {
        $stmt = db()->prepare("SELECT id, full_name, email, ic_number FROM users WHERE email = ? AND role = 'coach'");
        $stmt->execute([$email]);
        $coach = $stmt->fetch();

        if ($coach) {
            $cleanInputIc = preg_replace('/[^0-9]/', '', $icInput);
            $cleanDbIc    = preg_replace('/[^0-9]/', '', (string)($coach['ic_number'] ?? ''));

            if ($cleanDbIc !== '' && $cleanInputIc === $cleanDbIc) {
                // Verified successfully, update password
                $update = db()->prepare("UPDATE users SET password_hash = ? WHERE id = ?");
                $update->execute([password_hash($newPass, PASSWORD_DEFAULT), (int)$coach['id']]);
                audit((int)$coach['id'], 'forgot_password_reset', 'user', (int)$coach['id']);

                flash('success', 'Kata laluan akaun Jurulatih anda berjaya dikemas kini. Sila log masuk.');
                redirect('jurulatih/login.php');
            } else {
                flash('error', 'No. Kad Pengenalan tidak sepadan dengan maklumat pendaftaran e-mel tersebut.');
            }
        } else {
            flash('error', 'Akaun Jurulatih dengan alamat e-mel tersebut tidak ditemui.');
        }
    } else {
        flash('error', implode(' ', $errors));
    }
}

$pageTitle = 'Lupa Kata Laluan Jurulatih';
require BASE_PATH . '/partials/head.php';
?>
<div class="login-wrapper">
    <a href="<?= e(url('jurulatih/login.php')) ?>" class="login-back">
        <i class="fa-solid fa-arrow-left"></i>Kembali ke Log Masuk
    </a>
    <img src="<?= e(url('assets/images/Logo KVSkills.png')) ?>" class="login-logo" alt="Logo">
    <div class="login-brand">KVSKILLS HUB · JURULATIH</div>
    <div class="login-card" style="max-width: 480px;">
        <h2>Lupa Kata Laluan</h2>
        <div class="login-underline"></div>
        <p class="text-muted small mb-4 text-center">
            Sahkan identiti anda menggunakan e-mel rasmi berdaftar dan No. Kad Pengenalan untuk menetapkan kata laluan baharu.
        </p>

        <?php if ($m = flash('error')): ?>
            <div class="alert alert-danger py-2 small"><?= e($m) ?></div>
        <?php endif; ?>
        <?php if ($m = flash('success')): ?>
            <div class="alert alert-success py-2 small"><?= e($m) ?></div>
        <?php endif; ?>

        <form method="post">
            <?= Csrf::field() ?>
            <div class="mb-3">
                <label for="email" class="form-label small fw-semibold">E-mel Berdaftar Jurulatih <span class="text-danger">*</span></label>
                <div class="input-group login-input-group">
                    <span class="input-group-text"><i class="fa-solid fa-envelope"></i></span>
                    <input type="email" class="form-control" id="email" name="email" value="<?= e(old('email')) ?>" placeholder="jurulatih@kvskills.my" required autocomplete="email" autofocus>
                </div>
            </div>

            <div class="mb-3">
                <label for="ic_number" class="form-label small fw-semibold">No. Kad Pengenalan (No. IC) <span class="text-danger">*</span></label>
                <div class="input-group login-input-group">
                    <span class="input-group-text"><i class="fa-solid fa-id-card"></i></span>
                    <input type="text" class="form-control" id="ic_number" name="ic_number" value="<?= e(old('ic_number')) ?>" placeholder="Cth: 850512-04-5123" required>
                </div>
                <div class="form-text small">Masukkan No. Kad Pengenalan yang digunakan semasa pendaftaran akaun.</div>
            </div>

            <div class="mb-3">
                <label for="new_password" class="form-label small fw-semibold">Kata Laluan Baharu <span class="text-danger">*</span></label>
                <div class="input-group login-input-group">
                    <span class="input-group-text"><i class="fa-solid fa-lock"></i></span>
                    <input type="password" class="form-control" id="new_password" name="new_password" placeholder="Minimum 8 aksara" required autocomplete="new-password">
                </div>
            </div>

            <div class="mb-3">
                <label for="confirm_password" class="form-label small fw-semibold">Pengesahan Kata Laluan Baharu <span class="text-danger">*</span></label>
                <div class="input-group login-input-group">
                    <span class="input-group-text"><i class="fa-solid fa-shield-halved"></i></span>
                    <input type="password" class="form-control" id="confirm_password" name="confirm_password" placeholder="Ulang kata laluan baharu" required autocomplete="new-password">
                </div>
            </div>

            <button class="login-btn mt-2" type="submit">
                <i class="fa-solid fa-key me-2"></i>Tetapkan Semula Kata Laluan
            </button>

            <div class="text-center mt-3 small">
                Ingat kata laluan anda? <a href="<?= e(url('jurulatih/login.php')) ?>" class="fw-bold text-primary">Log Masuk di sini</a>
            </div>
        </form>
    </div>
</div>
</body>
</html>
