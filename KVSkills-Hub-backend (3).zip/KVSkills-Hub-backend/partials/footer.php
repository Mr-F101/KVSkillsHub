<footer class="site-footer text-center py-4 mt-5">
    <div class="container">
        <p class="mb-1 text-muted small">&copy; <?= date('Y') ?> KVSkills Hub Malaysia &middot; Bahagian Pendidikan dan Latihan Teknikal Vokasional (BPLTV)</p>
        <p class="mb-0 text-muted small" style="font-size: 11.5px; opacity: 0.85;">Kementerian Pendidikan Malaysia</p>
    </div>
</footer>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/js/bootstrap.bundle.min.js"></script>
<script src="<?= e(url('assets/js/script.js')) ?>"></script>
</body></html>
