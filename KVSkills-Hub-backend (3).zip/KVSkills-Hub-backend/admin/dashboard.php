<?php
declare(strict_types=1);
require_once dirname(__DIR__) . '/config/bootstrap.php';
Auth::requireLogin('admin');
Auth::refresh();
$user = Auth::user();

if (is_post() && input('action') === 'approve_user') {
    Csrf::verify();
    $uid = (int)input('user_id');
    if ($uid > 0 && $uid !== Auth::id()) {
        $stmt = db()->prepare("UPDATE users SET status='active', approved_at=NOW(), approved_by=? WHERE id=? AND status='pending'");
        $stmt->execute([Auth::id(), $uid]);
        if ($stmt->rowCount() > 0) {
            audit(Auth::id(), 'approve_user', 'user', $uid);
            flash('success', 'Akaun pengguna telah diluluskan.');
        }
    }
    redirect('admin/dashboard.php');
}

// Quick action: toggle PT score entry switch directly from dashboard
if (is_post() && input('action') === 'toggle_pt_scoring') {
    Csrf::verify();
    $current = is_pt_score_entry_enabled();
    $newVal  = $current ? '0' : '1';
    set_setting('pt_score_entry_enabled', $newVal, 'Kebenaran kemasukan markah oleh Pegawai Teknikal');
    audit(Auth::id(), 'toggle_pt_score_entry', 'system_settings', 0, ['enabled' => $newVal]);

    if ($newVal === '1') {
        flash('success', 'Kemasukan markah oleh Pegawai Teknikal telah <strong>DIBUKA</strong>.');
    } else {
        flash('warning', 'Kemasukan markah oleh Pegawai Teknikal telah <strong>DITUTUP / DIKUNCI</strong>.');
    }
    redirect('admin/dashboard.php');
}

$counts = [
    'pending_users'   => (int)db()->query("SELECT COUNT(*) FROM users WHERE status='pending'")->fetchColumn(),
    'active_admins'   => (int)db()->query("SELECT COUNT(*) FROM users WHERE role='admin' AND status='active'")->fetchColumn(),
    'active_tech'     => (int)db()->query("SELECT COUNT(*) FROM users WHERE role='technical' AND status='active'")->fetchColumn(),
    'active_coaches'  => (int)db()->query("SELECT COUNT(*) FROM users WHERE role='coach' AND status='active'")->fetchColumn(),
    'submitted_regs'  => (int)db()->query("SELECT COUNT(*) FROM registrations WHERE status='submitted'")->fetchColumn(),
    'approved_regs'   => (int)db()->query("SELECT COUNT(*) FROM registrations WHERE status='approved'")->fetchColumn(),
    'published_res'   => (int)db()->query("SELECT COUNT(*) FROM results WHERE is_published=1")->fetchColumn(),
    'total_docs'      => (int)db()->query("SELECT COUNT(*) FROM documents WHERE is_active=1")->fetchColumn(),
];

$comp = active_competition();
$pendingUsers = db()->query("SELECT u.*, z.name AS zone_name FROM users u LEFT JOIN zones z ON z.id=u.zone_id WHERE u.status='pending' ORDER BY u.created_at DESC LIMIT 6")->fetchAll();
$recentRegs = db()->query("SELECT r.id, r.participant_name, r.institution, s.name AS skill_name, z.name AS zone_name, r.created_at FROM registrations r JOIN skills s ON s.id=r.skill_id JOIN zones z ON z.id=r.zone_id WHERE r.status='submitted' ORDER BY r.created_at DESC LIMIT 6")->fetchAll();

$pageTitle = 'Dashboard Pentadbir';
$activePage = 'admin_dashboard';
require BASE_PATH . '/partials/head.php';
require BASE_PATH . '/partials/sidebar.php';
require BASE_PATH . '/partials/flash.php';
?>
<section class="dashboard-header py-4">
    <div class="container text-center">
        <div class="d-inline-flex align-items-center gap-2 px-3 py-1.5 mb-2 rounded-pill" style="background: #eff6ff; border: 1px solid #bfdbfe; font-size: 11.5px; font-weight: 700; letter-spacing: 0.06em; text-transform: uppercase; color: #1d4ed8;">
            <i class="fa-solid fa-shield-halved text-warning"></i>
            <span>Pusat Kawalan Pentadbir Kebangsaan</span>
        </div>
        <h1 class="display-6 fw-bold text-dark mb-1">Dashboard Pentadbir Sistem</h1>
        <p class="text-muted mb-2"><?= e($user['full_name']) ?> &middot; Kawalan &amp; Pengurusan Penuh Sistem KVSkills Hub</p>
        <?php if ($comp): ?>
            <div class="event-pill">
                <i class="fa-solid fa-trophy text-warning"></i>
                <span>Edisi Semasa: <strong><?= e($comp['name']) ?></strong> (Status: <?= ucfirst(e($comp['status'])) ?>)</span>
            </div>
        <?php endif; ?>
    </div>
</section>

<section class="container py-4">
    <?php $isPtScoring = is_pt_score_entry_enabled(); ?>
    <!-- MASTER TOGGLE SWITCH CARD FOR PT SCORING ENTRY -->
    <div class="card border-0 shadow-sm mb-4 <?= $isPtScoring ? 'border-start border-4 border-success' : 'border-start border-4 border-danger' ?>">
        <div class="card-body p-4">
            <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3">
                <div class="d-flex align-items-center gap-3">
                    <div class="p-3 rounded-circle <?= $isPtScoring ? 'bg-success bg-opacity-10 text-success' : 'bg-danger bg-opacity-10 text-danger' ?>" style="font-size: 24px; width: 56px; height: 56px; display: grid; place-items: center;">
                        <i class="fa-solid <?= $isPtScoring ? 'fa-lock-open' : 'fa-lock' ?>"></i>
                    </div>
                    <div>
                        <div class="d-flex align-items-center gap-2 mb-1">
                            <h2 class="h5 mb-0 fw-bold text-dark">Suis Kemasukan Markah Pegawai Teknikal</h2>
                            <span class="badge <?= $isPtScoring ? 'bg-success' : 'bg-danger' ?> fs-6 px-3 py-1">
                                <?= $isPtScoring ? 'DIBUKA (AKTIF)' : 'DITUTUP (DIKUNCI)' ?>
                            </span>
                        </div>
                        <p class="text-muted mb-0 small">
                            <?= $isPtScoring
                                ? 'Pegawai Teknikal dibenarkan memasukkan dan mengemas kini markah peserta bagi zon masing-masing.'
                                : 'Kemasukan markah oleh Pegawai Teknikal telah dikunci. Borang dan butang simpan markah pada portal PT kini dinyahaktifkan.'
                            ?>
                        </p>
                    </div>
                </div>
                <div>
                    <form method="post" class="m-0" onsubmit="return confirm('Adakah anda pasti ingin mengubah status kebenaran kemasukan markah bagi Pegawai Teknikal?')">
                        <?= Csrf::field() ?>
                        <input type="hidden" name="action" value="toggle_pt_scoring">
                        <button type="submit" class="btn <?= $isPtScoring ? 'btn-danger' : 'btn-success' ?> px-4 shadow-sm text-nowrap">
                            <i class="fa-solid <?= $isPtScoring ? 'fa-lock me-1' : 'fa-lock-open me-1' ?>"></i>
                            <?= $isPtScoring ? 'Tutup Kemasukan Markah' : 'Buka Kemasukan Markah' ?>
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- STATS CARDS -->
    <div class="row g-3 mb-4">
        <div class="col-6 col-lg-3">
            <div class="stat-card">
                <i class="fa-solid fa-user-clock text-warning"></i>
                <strong><?= $counts['pending_users'] ?></strong>
                <span>Akaun Menunggu</span>
            </div>
        </div>
        <div class="col-6 col-lg-3">
            <div class="stat-card">
                <i class="fa-solid fa-user-gear text-primary"></i>
                <strong><?= $counts['active_tech'] ?></strong>
                <span>Pegawai Teknikal</span>
            </div>
        </div>
        <div class="col-6 col-lg-3">
            <div class="stat-card">
                <i class="fa-solid fa-user-tie text-success"></i>
                <strong><?= $counts['active_coaches'] ?></strong>
                <span>Jurulatih Aktif</span>
            </div>
        </div>
        <div class="col-6 col-lg-3">
            <div class="stat-card">
                <i class="fa-solid fa-clipboard-check text-info"></i>
                <strong><?= $counts['submitted_regs'] ?></strong>
                <span>Pendaftaran Menunggu</span>
            </div>
        </div>
    </div>

    <!-- QUICK MODULE SHORTCUTS -->
    <div class="row g-3 mb-4">
        <div class="col-6 col-md-3">
            <a class="dashboard-card py-3 px-2" href="<?= e(url('admin/pengguna.php')) ?>">
                <i class="fa-solid fa-users-gear text-primary fs-3 mb-2"></i>
                <h4 class="fs-6 mb-0">Pengguna</h4>
            </a>
        </div>
        <div class="col-6 col-md-3">
            <a class="dashboard-card py-3 px-2" href="<?= e(url('admin/pegawai_teknikal.php')) ?>">
                <i class="fa-solid fa-user-gear text-warning fs-3 mb-2"></i>
                <h4 class="fs-6 mb-0">Pegawai Teknikal</h4>
            </a>
        </div>
        <div class="col-6 col-md-3">
            <a class="dashboard-card py-3 px-2" href="<?= e(url('admin/keputusan.php')) ?>">
                <i class="fa-solid fa-ranking-star text-info fs-3 mb-2"></i>
                <h4 class="fs-6 mb-0">Keputusan</h4>
            </a>
        </div>
        <div class="col-6 col-md-3">
            <a class="dashboard-card py-3 px-2" href="<?= e(url('admin/tetapan.php')) ?>">
                <i class="fa-solid fa-gear text-secondary fs-3 mb-2"></i>
                <h4 class="fs-6 mb-0">Tetapan</h4>
            </a>
        </div>
    </div>

    <!-- TABLES ROW -->
    <div class="row g-4">
        <!-- PENDING USERS -->
        <div class="col-lg-6">
            <div class="card shadow-sm h-100">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <h2 class="h5 mb-0"><i class="fa-solid fa-user-clock me-2 text-warning"></i>Akaun Pengguna Menunggu Kelulusan</h2>
                        <a href="<?= e(url('admin/pengguna.php?status=pending')) ?>" class="btn btn-sm btn-outline-primary">Lihat Semua</a>
                    </div>
                    <div class="table-responsive">
                        <table class="table table-sm table-hover align-middle">
                            <thead>
                                <tr>
                                    <th>Nama / Emel</th>
                                    <th>Peranan</th>
                                    <th>Tindakan</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($pendingUsers as $pu): ?>
                                    <tr>
                                        <td>
                                            <strong><?= e($pu['full_name']) ?></strong><br>
                                            <small class="text-muted"><?= e($pu['email']) ?></small>
                                        </td>
                                        <td>
                                            <span class="badge text-bg-secondary"><?= e(ucfirst($pu['role'])) ?></span>
                                        </td>
                                        <td>
                                            <form method="post" class="d-inline">
                                                <?= Csrf::field() ?>
                                                <input type="hidden" name="action" value="approve_user">
                                                <input type="hidden" name="user_id" value="<?= (int)$pu['id'] ?>">
                                                <button class="btn btn-sm btn-success" type="submit" title="Luluskan Akaun">
                                                    <i class="fa-solid fa-check me-1"></i>Lulus
                                                </button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                                <?php if (!$pendingUsers): ?>
                                    <tr>
                                        <td colspan="3" class="text-center text-muted py-3">Tiada akaun menunggu kelulusan.</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <!-- PENDING REGISTRATIONS -->
        <div class="col-lg-6">
            <div class="card shadow-sm h-100">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <h2 class="h5 mb-0"><i class="fa-solid fa-clipboard-check me-2 text-primary"></i>Pendaftaran Peserta Terkini</h2>
                        <span class="badge bg-light text-secondary border">5 Terkini</span>
                    </div>
                    <div class="table-responsive">
                        <table class="table table-sm table-hover align-middle">
                            <thead>
                                <tr>
                                    <th>Peserta / Institusi</th>
                                    <th>Bidang</th>
                                    <th>Zon</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($recentRegs as $r): ?>
                                    <tr>
                                        <td>
                                            <strong><?= e($r['participant_name']) ?></strong><br>
                                            <small class="text-muted"><?= e($r['institution']) ?></small>
                                        </td>
                                        <td><?= e($r['skill_name']) ?></td>
                                        <td><span class="badge text-bg-light border"><?= e($r['zone_name']) ?></span></td>
                                    </tr>
                                <?php endforeach; ?>
                                <?php if (!$recentRegs): ?>
                                    <tr>
                                        <td colspan="3" class="text-center text-muted py-3">Tiada pendaftaran menunggu semakan.</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php require BASE_PATH . '/partials/footer.php'; ?>